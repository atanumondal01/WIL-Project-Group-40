"""Browser chat and background recording ingestion, served only on localhost."""
from __future__ import annotations
import argparse
import logging
import os
from pathlib import Path
import re
import tempfile
import threading
import time
from urllib.parse import urlsplit
from werkzeug.exceptions import HTTPException

from flask import Flask, abort, jsonify, render_template, request, send_file
from .rag import AUDIO_EXTENSIONS, Config, Pipeline, Store, answer_question, configure_logging
from .subjects import DEFAULT_SUBJECT, SubjectCatalog

APP_VERSION = "2026-09-30.2"
MAX_AUDIO_UPLOAD = 1024 * 1024 * 1024
_AUDIO_LOCK = threading.Lock()


def _audio_filename(name):
    if (not isinstance(name, str) or not name or len(name) > 180 or name != name.strip()
            or name.startswith(".") or name.endswith(".") or re.search(r'[<>:"/\\|?*\x00-\x1f]', name)
            or Path(name).suffix.lower() not in AUDIO_EXTENSIONS
            or re.fullmatch(r"(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?", name, re.I)):
        raise ValueError("Use a valid audio filename without folders or special path characters.")
    return name


def _publish_audio(temporary, destination):
    # Windows rename is atomic and refuses an existing destination. On Unix,
    # hard-link publication provides the same no-overwrite guarantee.
    if os.name == "nt":
        temporary.rename(destination)
    else:
        os.link(temporary, destination)
        temporary.unlink()


def create_app(config=None):
    config = config or Config.load()
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 64 * 1024
    store = Store(config)
    catalog = SubjectCatalog(config)
    for subject in catalog.list():
        catalog.folder(subject["id"]).mkdir(parents=True, exist_ok=True)
    chat_lock = threading.Lock()

    @app.errorhandler(Exception)
    def api_error(exc):
        if isinstance(exc, HTTPException):
            return jsonify(error=exc.description), exc.code
        logging.getLogger("lecture_rag").exception("Application request failed")
        return jsonify(error="The lecture library could not be read. Check logs/processing.log and restart the app."), 503

    @app.before_request
    def local_requests_only():
        if request.host.split(":")[0] not in {"127.0.0.1", "localhost"}:
            abort(403)
        origin = request.headers.get("Origin")
        if origin and urlsplit(origin).netloc != request.host:
            abort(403)
        if request.endpoint == "upload_audio":
            request.max_content_length = MAX_AUDIO_UPLOAD

    def selected_subject(value=DEFAULT_SUBJECT):
        try:
            return catalog.get(value)
        except ValueError as exc:
            abort(400, description=str(exc))

    def subject_summary(subject, records):
        files = catalog.records(subject["id"], records)
        return {**subject, "total": len(files), "ready": sum(r["status"] == "ready" for r in files),
                "chunks": sum(r["chunks"] for r in files),
                "indexed_seconds": sum(r["indexed"] for r in files)}

    def validate_media_subject(record):
        if "subject" in request.args:
            subject = selected_subject(request.args["subject"])
            if catalog.for_file(record["path"]) != subject["id"]:
                abort(404)

    @app.after_request
    def headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; "
            "media-src 'self'; connect-src 'self'; frame-ancestors 'none'")
        if request.path.startswith("/api/") or request.path == '/':
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/")
    def home():
        return render_template("index.html", app_version=APP_VERSION)

    @app.get("/api/status")
    def status():
        subject = selected_subject(request.args.get("subject", DEFAULT_SUBJECT))
        records = store.status()
        files = [{k: r[k] for k in ("path", "status", "duration", "language", "error",
                  "transcribed", "indexed", "chunks", "updated", "duplicate_of")}
                 for r in catalog.records(subject["id"], records)]
        return jsonify(files=files, input_folder=subject["folder"], app_version=APP_VERSION,
                       subject=subject, subjects=[subject_summary(s, records) for s in catalog.list()],
                       chunks=sum(r["chunks"] for r in files),
                       ready=sum(r["status"] == "ready" for r in files),
                       total=len(files), indexed_seconds=sum(r["indexed"] for r in files))

    @app.post("/api/subjects")
    def create_subject():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(error="A subject name is required."), 400
        try:
            return jsonify(subject=catalog.create(data.get("name"))), 201
        except ValueError as exc:
            return jsonify(error=str(exc)), 400

    @app.patch("/api/subjects/<subject_id>")
    def rename_subject(subject_id):
        selected_subject(subject_id)
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(error="A subject name is required."), 400
        try:
            return jsonify(subject=catalog.rename(subject_id, data.get("name")))
        except ValueError as exc:
            return jsonify(error=str(exc)), 400

    @app.post("/api/subjects/<subject_id>/audio")
    def upload_audio(subject_id):
        subject = selected_subject(subject_id)
        if request.mimetype != "multipart/form-data":
            return jsonify(error="Choose audio files to upload."), 400
        incoming = request.files.getlist("files")
        if not incoming or len(incoming) > 50:
            return jsonify(error="Choose between 1 and 50 audio files per upload."), 400
        try:
            names = [_audio_filename(upload.filename) for upload in incoming]
            folder = catalog.folder(subject_id)
        except ValueError as exc:
            return jsonify(error=str(exc)), 400
        if len({name.casefold() for name in names}) != len(names):
            return jsonify(error="An upload contains repeated filenames. Rename the files first."), 409
        temporary_files = []
        published = []
        with _AUDIO_LOCK:
            folder.mkdir(parents=True, exist_ok=True)
            existing = {path.name.casefold() for path in folder.iterdir()}
            existing.update(Path(record["path"]).name.casefold()
                            for record in catalog.records(subject_id, store.status()))
            if subject_id == DEFAULT_SUBJECT:
                # The original nine recordings stay directly under audio lec.
                # Include them even before the watcher has indexed new files.
                existing.update(path.name.casefold() for path in config.audio_dir.iterdir() if path.is_file())
            if any(name.casefold() in existing for name in names):
                return jsonify(error="A recording with that filename already exists. Rename the new file first."), 409
            try:
                total = 0
                for upload, name in zip(incoming, names):
                    descriptor, temporary_name = tempfile.mkstemp(prefix=".audio-", suffix=".upload", dir=folder)
                    temporary = Path(temporary_name)
                    temporary_files.append(temporary)
                    size = 0
                    with os.fdopen(descriptor, "wb") as output:
                        while chunk := upload.stream.read(1024 * 1024):
                            size += len(chunk)
                            total += len(chunk)
                            if total > MAX_AUDIO_UPLOAD:
                                abort(413, description="Upload at most 1 GB at a time.")
                            output.write(chunk)
                        output.flush()
                        os.fsync(output.fileno())
                    if not size:
                        abort(400, description=f"{name} is empty. Choose a recording with audio.")
                for temporary, name in zip(temporary_files, names):
                    destination = folder / name
                    try:
                        _publish_audio(temporary, destination)
                    except FileExistsError:
                        abort(409, description="A recording with that filename already exists. Rename the new file first.")
                    published.append(destination)
            except BaseException:
                for destination in published:
                    destination.unlink(missing_ok=True)
                raise
            finally:
                for temporary in temporary_files:
                    temporary.unlink(missing_ok=True)
        return jsonify(subject=subject,
                       files=[{"name": path.name, "path": path.relative_to(config.audio_dir.resolve()).as_posix()}
                              for path in published],
                       message=f"Added {len(published)} recordings. Processing starts automatically."), 201

    @app.delete("/api/subjects/<subject_id>/audio")
    def delete_audio(subject_id):
        subject = selected_subject(subject_id)
        data = request.get_json(silent=True)
        if not isinstance(data, dict) or not isinstance(data.get("file"), str):
            return jsonify(error="Choose a recording to delete."), 400
        name = data["file"]
        record = store.file(name)
        if not record or catalog.for_file(record["path"]) != subject_id:
            return jsonify(error="That recording does not belong to the selected subject."), 404
        root = config.audio_dir.resolve()
        path = (root / Path(record["path"])).resolve()
        if not path.is_relative_to(root) or path.suffix.lower() not in AUDIO_EXTENSIONS:
            return jsonify(error="The recording path is invalid."), 400
        with _AUDIO_LOCK:
            # Recheck after waiting for an upload or another deletion.
            record = store.file(name)
            if not record or catalog.for_file(record["path"]) != subject_id:
                return jsonify(error="That recording is no longer in this subject."), 404
            try:
                path.unlink(missing_ok=True)
            except PermissionError:
                return jsonify(error="This recording is currently in use. Wait for processing to finish, then try again."), 409
            Pipeline(config).delete_recording_data(name)
        return jsonify(subject=subject, file=name,
                       message=f"Deleted {Path(name).name} and its transcript files.")

    @app.post("/api/chat")
    def chat():
        data = request.get_json(silent=True)
        if not isinstance(data, dict) or not isinstance(data.get("question"), str):
            return jsonify(error="A text question is required."), 400
        lecture = data.get("lecture") or None
        subject = selected_subject(data.get("subject", DEFAULT_SUBJECT))
        history = data.get("history", [])
        if (lecture is not None and not isinstance(lecture, str)) or not isinstance(history, list):
            return jsonify(error="Invalid lecture or conversation history."), 400
        if lecture and not store.file(lecture):
            return jsonify(error="That lecture is no longer in the library."), 404
        if lecture and catalog.for_file(lecture) != subject["id"]:
            return jsonify(error="That lecture does not belong to the selected subject."), 404
        if not chat_lock.acquire(blocking=False):
            return jsonify(error="Another answer is being generated. Please try again shortly."), 429
        try:
            return jsonify(answer_question(config, data["question"], lecture, history, subject=subject["id"]))
        except ValueError as exc:
            return jsonify(error=str(exc)), 400
        except Exception as exc:
            logging.getLogger("lecture_rag").exception("Chat failed")
            return jsonify(error=str(exc)), 503
        finally:
            chat_lock.release()

    @app.get("/api/audio")
    def audio():
        name = request.args.get("file", "")
        record = store.file(name)
        if not record:
            abort(404)
        validate_media_subject(record)
        path = (config.audio_dir / name).resolve()
        if not path.is_relative_to(config.audio_dir.resolve()) or not path.is_file():
            abort(404)
        return send_file(path, conditional=True)

    @app.get("/api/transcript")
    def transcript():
        record = store.file(request.args.get("file", ""))
        extension = request.args.get("format", "txt")
        if not record or extension not in {"txt", "json", "srt"}:
            abort(404)
        validate_media_subject(record)
        path = Pipeline(config).export_base(record).with_suffix("." + extension)
        if not path.exists():
            return jsonify(error="This lecture has no completed transcript sections yet."), 404
        return send_file(path, as_attachment=True, download_name=Path(record["path"]).stem + "." + extension)

    return app


def watch_recordings(config):
    pipeline = Pipeline(config)
    while True:
        try:
            pipeline.run(watch=True)
            return
        except Exception as exc:
            logging.getLogger("lecture_rag").warning("Watcher: %s", exc)
            time.sleep(max(5, config.poll_seconds))


def main():
    parser = argparse.ArgumentParser(description="Lecture Library — local audio RAG chatbot")
    parser.add_argument("--no-watch", action="store_true", help="Serve chat without starting a processing worker")
    args = parser.parse_args()
    config = Config.load()
    configure_logging(config)
    if not args.no_watch:
        threading.Thread(target=watch_recordings, args=(config,), name="lecture-watcher", daemon=True).start()
    create_app(config).run(host="127.0.0.1", port=config.port, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
