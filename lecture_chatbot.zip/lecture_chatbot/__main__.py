"""Start the browser app and recording watcher with python -m lecture_chatbot."""
from .web import main

if __name__ == "__main__":
    main()
