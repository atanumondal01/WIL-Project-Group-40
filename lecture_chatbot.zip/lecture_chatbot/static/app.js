const $ = (id) => document.getElementById(id);
let history = [], sending = false, uploading = false, savingSubject = false, deletingRecording = false;
let activeSubjectId = 'case-studies', subjects = [], currentStatus = null;
let changingSubject = true, statusAvailable = false, statusRequest = 0;
let filesKey = '', subjectsKey = '', subjectDialogMode = 'create';

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function duration(seconds) {
  if (seconds < 3600) return `${Math.floor(seconds / 60)} min`;
  return `${(seconds / 3600).toFixed(1)} hr`;
}
function fileName(path) { return path.split(/[\\/]/).pop(); }
function busy() { return sending || uploading || savingSubject || deletingRecording || changingSubject; }
function selectedSubject() { return subjects.find(subject => subject.id === activeSubjectId); }
function updateControls() {
  const locked = busy();
  const hasSubject = Boolean(selectedSubject());
  $('subject-select').disabled = locked || !subjects.length;
  $('rename-subject').disabled = locked || !hasSubject;
  $('add-subject').disabled = locked || !statusAvailable;
  $('add-lectures').disabled = $('empty-add-lectures').disabled = locked || !hasSubject;
  $('audio-files').disabled = locked || !hasSubject;
  $('new-chat').disabled = locked;
  $('lecture-select').disabled = locked;
  $('question').disabled = sending || changingSubject;
  $('send').disabled = locked || !statusAvailable || !(currentStatus?.chunks > 0);
  document.querySelectorAll('.subject-card, .recording-name, .delete-recording').forEach(node => { node.disabled = locked; });
  document.querySelectorAll('[data-question]').forEach(node => { node.disabled = locked || !(currentStatus?.chunks > 0); });
}
function closePlayer() {
  const player = $('audio-player');
  player.pause();
  player.onloadedmetadata = null;
  player.removeAttribute('src');
  player.load();
  $('player-panel').hidden = true;
}
function resetConversation() {
  history = [];
  $('messages').replaceChildren();
  $('intro').hidden = false;
  $('question').value = '';
  chooseLecture('');
  closePlayer();
}
function chooseLecture(name) {
  $('lecture-select').value = name;
  document.querySelectorAll('.recording').forEach(node => node.classList.toggle('active', node.dataset.file === name));
}
function showSubjects() {
  const key = JSON.stringify([activeSubjectId, subjects]);
  if (key !== subjectsKey) {
    subjectsKey = key;
    $('subject-select').replaceChildren();
    $('subject-cards').replaceChildren();
    subjects.forEach((subject, index) => {
      $('subject-select').append(new Option(subject.name, subject.id));
      const card = element('button', 'subject-card');
      card.type = 'button';
      card.dataset.subject = subject.id;
      card.classList.toggle('active', subject.id === activeSubjectId);
      card.setAttribute('aria-pressed', String(subject.id === activeSubjectId));
      const top = element('span', 'subject-card-top');
      top.append(element('span', 'subject-number', String(index + 1).padStart(2, '0')),
        element('span', 'subject-marker', subject.id === activeSubjectId ? 'Selected' : '↗'));
      const count = subject.total || 0;
      card.append(top, element('strong', 'subject-title', subject.name),
        element('span', 'subject-detail', count ? `${count} recording${count === 1 ? '' : 's'} · ${subject.ready || 0} ready` : 'Add your first lecture'));
      card.addEventListener('click', () => switchSubject(subject.id));
      $('subject-cards').append(card);
    });
  }
  $('subject-select').value = activeSubjectId;
  const subject = selectedSubject();
  if (subject) {
    $('breadcrumb-subject').textContent = subject.name;
    $('current-subject-name').textContent = subject.name;
    $('folder-name').textContent = subject.folder;
  }
}
async function switchSubject(subjectId) {
  if (busy() || subjectId === activeSubjectId || !subjects.some(subject => subject.id === subjectId)) return;
  await loadSubject(subjectId);
}
async function loadSubject(subjectId) {
  activeSubjectId = subjectId;
  changingSubject = true;
  statusAvailable = false;
  currentStatus = null;
  filesKey = '';
  resetConversation();
  $('upload-status').hidden = true;
  $('recordings').replaceChildren(element('p', 'muted', 'Loading this subject…'));
  $('lecture-select').replaceChildren(new Option('All lectures in this subject', ''));
  for (const id of ['file-count', 'stat-recordings', 'stat-chunks']) $(id).textContent = '0';
  $('stat-hours').textContent = '0 min';
  $('processing-banner').textContent = 'Checking this subject’s recordings…';
  $('empty-subject').hidden = true;
  showSubjects();
  updateControls();
  await refreshStatus();
}
function showRecordings(files) {
  const key = JSON.stringify([activeSubjectId, files]);
  if (key === filesKey) return;
  filesKey = key;
  $('recordings').replaceChildren();
  const previous = $('lecture-select').value;
  $('lecture-select').replaceChildren(new Option('All lectures in this subject', ''));
  for (const file of files) {
    const displayName = fileName(file.path);
    const card = element('div', 'recording'); card.dataset.file = file.path;
    const head = element('div', 'recording-head');
    const name = element('button', 'recording-name', displayName.replace(/\.[^.]+$/, ''));
    name.type = 'button'; name.addEventListener('click', () => { if (!busy()) chooseLecture(file.path); });
    head.append(element('span', 'recording-icon', '≋'), name); card.append(head);
    const percent = file.duration ? Math.min(100, Math.floor(file.indexed / file.duration * 100)) : 0;
    const labels = {ready: 'Ready to explore', queued: 'Waiting to process', processing: `Processing · ${percent}%`, error: 'Needs attention', duplicate: 'Duplicate recording', transcribed: 'Awaiting index'};
    const meta = element('div', 'recording-meta');
    meta.append(element('span', '', file.duration ? duration(file.duration) : 'Audio recording'), element('span', '', labels[file.status] || file.status));
    card.append(meta);
    if (file.status === 'processing') {
      const bar = element('progress', 'progress'); bar.max = 100; bar.value = percent;
      bar.setAttribute('aria-label', `${displayName} processing progress`); card.append(bar);
    }
    if (file.error) {
      const detail = element('details', 'file-error');
      detail.append(element('summary', '', 'Processing error'), element('p', '', file.error)); card.append(detail);
    }
    if (file.duplicate_of) card.append(element('p', 'muted', `Same audio as ${fileName(file.duplicate_of)}`));
    const actions = element('div', 'recording-actions');
    if (file.transcribed > 0) {
      const downloads = element('div', 'downloads');
      for (const format of ['txt', 'srt', 'json']) {
        const link = element('a', '', format.toUpperCase());
        link.href = `/api/transcript?subject=${encodeURIComponent(activeSubjectId)}&file=${encodeURIComponent(file.path)}&format=${format}`;
        link.title = `Download ${format.toUpperCase()} transcript`; downloads.append(link);
      }
      actions.append(downloads);
    }
    const remove = element('button', 'delete-recording', 'Delete lecture');
    remove.type = 'button';
    remove.setAttribute('aria-label', `Delete ${displayName}`);
    remove.title = 'Permanently delete this recording and its transcript files';
    remove.addEventListener('click', () => deleteRecording(file));
    actions.append(remove);
    card.append(actions);
    $('recordings').append(card);
    if (file.status !== 'duplicate') $('lecture-select').append(new Option(displayName.replace(/\.[^.]+$/, ''), file.path));
  }
  if (!files.length) $('recordings').append(element('p', 'muted', 'No recordings yet. Add lectures to this subject to get started.'));
  chooseLecture(files.some(file => file.path === previous && file.status !== 'duplicate') ? previous : '');
}
async function refreshStatus() {
  const requestedSubject = activeSubjectId, request = ++statusRequest;
  try {
    const response = await fetch(`/api/status?subject=${encodeURIComponent(requestedSubject)}`, {cache: 'no-store'});
    if (!response.ok) throw new Error('Status unavailable');
    const status = await response.json();
    if (requestedSubject !== activeSubjectId || request !== statusRequest) return;
    if (!status.subject || status.subject.id !== requestedSubject) throw new Error('Subject status unavailable');
    currentStatus = status;
    statusAvailable = true;
    subjects = status.subjects;
    showSubjects();
    showRecordings(status.files);
    $('file-count').textContent = status.total;
    $('stat-recordings').textContent = status.total;
    $('stat-hours').textContent = duration(status.indexed_seconds);
    $('stat-chunks').textContent = status.chunks.toLocaleString();
    $('folder-name').textContent = status.input_folder || status.subject.folder;
    $('empty-subject').hidden = status.total > 0;
    $('suggestions').hidden = status.total === 0;
    const working = status.files.find(file => file.status === 'processing');
    const failed = status.files.filter(file => file.status === 'error').length;
    const remaining = status.files.filter(file => !['ready', 'duplicate'].includes(file.status)).length;
    $('processing-banner').textContent = working ? `Processing ${fileName(working.path)} · You can ask about sections already indexed.` :
      failed ? `${failed} recording${failed === 1 ? '' : 's'} need attention. Expand the error in the library. Completed sections remain searchable.` :
      remaining ? `${remaining} recording${remaining === 1 ? '' : 's'} waiting to process. Progress is saved automatically.` :
      status.total ? `${status.subject.name} is up to date. Ask about any of its lectures.` : `Add lectures to ${status.subject.name} to begin.`;
  } catch (error) {
    if (requestedSubject !== activeSubjectId || request !== statusRequest) return;
    statusAvailable = false;
    $('processing-banner').textContent = 'Cannot connect to the app. Start the lecture chatbot and refresh this page.';
  } finally {
    if (requestedSubject === activeSubjectId && request === statusRequest) {
      changingSubject = false;
      updateControls();
    }
  }
}
function addMessage(role, text) {
  const node = element('article', `message ${role}`);
  if (role === 'assistant') node.append(element('div', 'message-label', 'LECTURE LIBRARY'));
  node.append(element('div', 'answer-text', text));
  $('messages').append(node); return node;
}
function playSource(source, subjectId) {
  if (subjectId !== activeSubjectId) return;
  const player = $('audio-player');
  player.pause();
  player.onloadedmetadata = () => { player.currentTime = source.start; };
  player.src = `/api/audio?subject=${encodeURIComponent(subjectId)}&file=${encodeURIComponent(source.file)}#t=${source.start},${source.end}`;
  player.load();
  player.play().catch(() => {});
  $('player-title').textContent = `${fileName(source.file)} · ${source.start_label}`;
  $('player-panel').hidden = false;
}
function addSources(node, sources, subjectId) {
  if (!sources.length) return;
  const list = element('div', 'source-list');
  for (const source of sources) {
    const card = element('div', 'source-card');
    const head = element('div', 'source-head');
    head.append(element('strong', '', `[${source.label}] ${fileName(source.file)}`));
    const play = element('button', 'source-play', `▶ ${source.start_label} – ${source.end_label}`);
    play.type = 'button'; play.addEventListener('click', () => playSource(source, subjectId)); head.append(play);
    const details = element('details');
    details.append(element('summary', '', 'Read the original passage'), element('p', '', source.text));
    card.append(head, details); list.append(card);
  }
  node.append(list);
}
function openSubjectDialog(mode) {
  if (busy()) return;
  subjectDialogMode = mode;
  const rename = mode === 'rename';
  $('subject-dialog-title').textContent = rename ? 'Rename this subject' : 'Add a subject';
  $('subject-dialog-description').textContent = rename ? 'Give this collection a name you’ll recognize.' : 'Give your lectures a home of their own.';
  $('subject-name').value = rename ? selectedSubject().name : '';
  $('save-subject').textContent = rename ? 'Save name' : 'Add subject';
  $('subject-error').hidden = true;
  $('subject-dialog').showModal();
  $('subject-name').focus();
  $('subject-name').select();
}
function uploadAudio(files, subjectId) {
  return new Promise((resolve, reject) => {
    const body = new FormData();
    files.forEach(file => body.append('files', file));
    const request = new XMLHttpRequest();
    request.open('POST', `/api/subjects/${encodeURIComponent(subjectId)}/audio`);
    request.responseType = 'json';
    request.timeout = 30 * 60 * 1000;
    request.upload.addEventListener('progress', event => {
      if (!event.lengthComputable) return;
      const percent = Math.min(100, Math.round(event.loaded / event.total * 100));
      $('upload-progress').value = percent;
      $('upload-status').textContent = percent === 100 ? 'Saving your recordings…' : `Adding ${files.length} recording${files.length === 1 ? '' : 's'} · ${percent}%`;
    });
    request.addEventListener('load', () => {
      if (request.status >= 200 && request.status < 300) resolve(request.response || {});
      else reject(new Error(request.response?.error || 'The recordings could not be added. Please try again.'));
    });
    request.addEventListener('error', () => reject(new Error('Connection lost while adding recordings. Check the app, then try again.')));
    request.addEventListener('timeout', () => reject(new Error('The upload took too long. Try fewer recordings at once.')));
    request.send(body);
  });
}
async function deleteRecording(file) {
  if (busy()) return;
  const subject = selectedSubject();
  const displayName = fileName(file.path);
  if (!subject || !window.confirm(`Permanently delete ${displayName} from ${subject.name}?\n\nThe original audio and generated transcript files will be deleted from this laptop.`)) return;
  const subjectId = activeSubjectId;
  deletingRecording = true;
  $('upload-status').hidden = false;
  $('upload-status').classList.remove('form-error');
  $('upload-status').textContent = `Deleting ${displayName}…`;
  updateControls();
  try {
    const response = await fetch(`/api/subjects/${encodeURIComponent(subjectId)}/audio`, {
      method: 'DELETE', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({file: file.path})
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'The recording could not be deleted.');
    if (subjectId === activeSubjectId) {
      resetConversation();
      filesKey = '';
      $('upload-status').textContent = result.message || `${displayName} was deleted.`;
    }
  } catch (error) {
    if (subjectId === activeSubjectId) {
      $('upload-status').textContent = error.message;
      $('upload-status').classList.add('form-error');
    }
  } finally {
    deletingRecording = false;
    await refreshStatus();
  }
}
$('audio-files').addEventListener('change', async () => {
  const files = Array.from($('audio-files').files);
  if (!files.length || busy()) return;
  const subjectId = activeSubjectId;
  uploading = true;
  $('upload-status').hidden = false;
  $('upload-status').classList.remove('form-error');
  $('upload-status').textContent = 'Adding your recordings…';
  $('upload-progress').hidden = false;
  $('upload-progress').value = 0;
  updateControls();
  try {
    const result = await uploadAudio(files, subjectId);
    if (subjectId === activeSubjectId) $('upload-status').textContent = result.message || 'Recordings added. Processing starts automatically.';
  } catch (error) {
    if (subjectId === activeSubjectId) {
      $('upload-status').textContent = error.message;
      $('upload-status').classList.add('form-error');
    }
  } finally {
    uploading = false;
    $('audio-files').value = '';
    $('upload-progress').hidden = true;
    await refreshStatus();
  }
});
$('subject-form').addEventListener('submit', async event => {
  event.preventDefault();
  if (busy()) return;
  const name = $('subject-name').value.trim();
  if (!name) { $('subject-name').focus(); return; }
  savingSubject = true;
  $('subject-error').hidden = true;
  $('save-subject').disabled = $('cancel-subject').disabled = $('subject-name').disabled = true;
  $('save-subject').textContent = 'Saving…';
  updateControls();
  try {
    const rename = subjectDialogMode === 'rename';
    const response = await fetch(rename ? `/api/subjects/${encodeURIComponent(activeSubjectId)}` : '/api/subjects', {
      method: rename ? 'PATCH' : 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({name})
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'The subject could not be saved.');
    const index = subjects.findIndex(subject => subject.id === result.subject.id);
    if (index === -1) subjects.push(result.subject);
    else subjects[index] = {...subjects[index], ...result.subject};
    $('subject-dialog').close();
    if (rename) { showSubjects(); await refreshStatus(); }
    else await loadSubject(result.subject.id);
  } catch (error) {
    $('subject-error').textContent = error.message;
    $('subject-error').hidden = false;
  } finally {
    savingSubject = false;
    $('save-subject').disabled = $('cancel-subject').disabled = $('subject-name').disabled = false;
    $('save-subject').textContent = subjectDialogMode === 'rename' ? 'Save name' : 'Add subject';
    updateControls();
  }
});
$('chat-form').addEventListener('submit', async event => {
  event.preventDefault();
  const question = $('question').value.trim();
  if (!question || busy() || $('send').disabled) return;
  const subjectId = activeSubjectId, lecture = $('lecture-select').value || null;
  sending = true; $('intro').hidden = true;
  addMessage('user', question); $('question').value = '';
  updateControls();
  const pending = addMessage('assistant', 'Reading the relevant passages…');
  pending.scrollIntoView({behavior: 'smooth', block: 'nearest'});
  try {
    const response = await fetch('/api/chat', {method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({question, subject: subjectId, lecture, history: history.slice(-6)})});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'The answer could not be generated.');
    if (activeSubjectId !== subjectId) return;
    pending.querySelector('.answer-text').textContent = result.answer;
    if (result.interpreted_question && result.interpreted_question !== question) {
      pending.querySelector('.answer-text').before(element('p', 'interpreted-question', `Understood as: ${result.interpreted_question}`));
    }
    addSources(pending, result.sources || [], subjectId);
    if ('lecture' in result) chooseLecture(result.lecture || '');
    history.push({role: 'user', content: question}, {role: 'assistant', content: result.answer});
  } catch (error) {
    if (activeSubjectId === subjectId) {
      pending.classList.add('error'); pending.querySelector('.answer-text').textContent = error.message;
      $('question').value = question;
    }
  } finally {
    sending = false;
    await refreshStatus();
    $('question').focus();
  }
});
$('question').addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); $('chat-form').requestSubmit(); }
});
$('lecture-select').addEventListener('change', event => { if (!busy()) chooseLecture(event.target.value); });
$('subject-select').addEventListener('change', event => switchSubject(event.target.value));
$('new-chat').addEventListener('click', () => { if (!busy()) { resetConversation(); $('question').focus(); } });
$('close-player').addEventListener('click', closePlayer);
$('add-subject').addEventListener('click', () => openSubjectDialog('create'));
$('rename-subject').addEventListener('click', () => openSubjectDialog('rename'));
$('cancel-subject').addEventListener('click', () => { if (!savingSubject) $('subject-dialog').close(); });
$('subject-dialog').addEventListener('cancel', event => { if (savingSubject) event.preventDefault(); });
for (const id of ['add-lectures', 'empty-add-lectures']) {
  $(id).addEventListener('click', () => { if (!busy()) $('audio-files').click(); });
}
document.querySelectorAll('[data-question]').forEach(button => button.addEventListener('click', () => {
  $('question').value = button.dataset.question; $('question').focus();
}));
refreshStatus();
setInterval(refreshStatus, 6000);
