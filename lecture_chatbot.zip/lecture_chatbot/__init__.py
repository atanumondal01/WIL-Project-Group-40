"""Lecture Library: local audio transcription and retrieval-based chat."""
