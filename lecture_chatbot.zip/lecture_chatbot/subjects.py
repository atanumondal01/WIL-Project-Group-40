"""Persistent subject names and safe audio folders, independent of the lecture index."""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import tempfile
import threading
import time
import uuid


DEFAULT_SUBJECT = "case-studies"
DEFAULT_SUBJECTS = (
    {"id": DEFAULT_SUBJECT, "name": "Case Studies of Data Science"},
    {"id": "subject-2", "name": "Advanced Programming Fundamentals"},
    {"id": "subject-3", "name": "Applied Analytics"},
    {"id": "subject-4", "name": "Data Visualization"},
)
_LEGACY_DEFAULT_NAMES = {
    DEFAULT_SUBJECT: "Case Studies",
    "subject-2": "Subject 2",
    "subject-3": "Subject 3",
    "subject-4": "Subject 4",
}
_CATALOG_LOCK = threading.RLock()
_SUBJECT_ID = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)*\Z")


class SubjectCatalog:
    """Keep stable IDs when names change; retain the original recordings in place."""

    def __init__(self, config):
        self.config = config
        self.path = config.data_dir / "subjects.json"
        with _CATALOG_LOCK:
            if not self.path.exists():
                self._save([dict(subject) for subject in DEFAULT_SUBJECTS])
            else:
                self._migrate_default_names()

    def _migrate_default_names(self):
        """Replace only untouched placeholder names while preserving stable folders."""
        subjects = self._load()
        defaults = {subject["id"]: subject["name"] for subject in DEFAULT_SUBJECTS}
        used = {subject["name"].casefold() for subject in subjects}
        changed = False
        for subject in subjects:
            old_name = _LEGACY_DEFAULT_NAMES.get(subject["id"])
            new_name = defaults.get(subject["id"])
            if (old_name and subject["name"] == old_name
                    and new_name.casefold() not in used - {old_name.casefold()}):
                used.remove(old_name.casefold())
                used.add(new_name.casefold())
                subject["name"] = new_name
                changed = True
        if changed:
            self._save(subjects)

    @staticmethod
    def _name(value):
        if not isinstance(value, str):
            raise ValueError("Enter a subject name.")
        name = " ".join(value.split())
        if not name or len(name) > 80 or any(ord(char) < 32 for char in name):
            raise ValueError("Subject names must contain 1 to 80 characters.")
        return name

    def _load(self):
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        subjects = payload.get("subjects") if isinstance(payload, dict) else None
        if not isinstance(subjects, list) or not subjects:
            raise ValueError("The subject catalog is invalid.")
        ids = set()
        names = set()
        for item in subjects:
            if (not isinstance(item, dict) or not isinstance(item.get("id"), str)
                    or not _SUBJECT_ID.fullmatch(item["id"]) or len(item["id"]) > 80
                    or item["id"] in ids):
                raise ValueError("The subject catalog is invalid.")
            name = self._name(item.get("name"))
            if name.casefold() in names:
                raise ValueError("The subject catalog has duplicate names.")
            ids.add(item["id"])
            names.add(name.casefold())
        if DEFAULT_SUBJECT not in ids:
            raise ValueError("The original Case Studies subject is missing from the catalog.")
        return [{"id": item["id"], "name": item["name"]} for item in subjects]

    def _save(self, subjects):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(prefix=".subjects-", suffix=".tmp", dir=self.path.parent)
        temporary = Path(temporary_name)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as output:
                json.dump({"version": 1, "subjects": subjects}, output, ensure_ascii=False, indent=2)
                output.write("\n")
                output.flush()
                os.fsync(output.fileno())
            for attempt in range(6):
                try:
                    os.replace(temporary, self.path)
                    break
                except PermissionError:
                    if attempt == 5:
                        raise
                    time.sleep(.05 * 2 ** attempt)
        finally:
            temporary.unlink(missing_ok=True)

    def _display(self, subject):
        return {**subject, "folder": f"{self.config.audio_dir.name}/{subject['id']}"}

    def list(self):
        with _CATALOG_LOCK:
            return [self._display(subject) for subject in self._load()]

    def get(self, subject_id):
        if not isinstance(subject_id, str):
            raise ValueError("Choose a valid subject.")
        for subject in self.list():
            if subject["id"] == subject_id:
                return subject
        raise ValueError("That subject is no longer in the library.")

    def for_file(self, path):
        """Paths in unassigned legacy folders belong to the original subject."""
        relative = Path(str(path).replace("\\", "/"))
        root = self.config.audio_dir.resolve()
        if relative.is_absolute() or ".." in relative.parts or not (root / relative).resolve().is_relative_to(root):
            raise ValueError("Invalid lecture path.")
        first = relative.parts[0] if len(relative.parts) > 1 else None
        ids = {subject["id"] for subject in self.list()}
        return first if first in ids else DEFAULT_SUBJECT

    def records(self, subject_id, records):
        self.get(subject_id)
        return [record for record in records if self.for_file(record["path"]) == subject_id]

    def folder(self, subject_id):
        self.get(subject_id)
        root = self.config.audio_dir.resolve()
        folder = (root / subject_id).resolve()
        if not folder.is_relative_to(root) or folder == root:
            raise ValueError("The subject audio folder is outside the library.")
        return folder

    def create(self, name):
        name = self._name(name)
        with _CATALOG_LOCK:
            subjects = self._load()
            if any(subject["name"].casefold() == name.casefold() for subject in subjects):
                raise ValueError("A subject with that name already exists.")
            stem = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:48].rstrip("-") or "subject"
            if re.fullmatch(r"(?:con|prn|aux|nul|com[1-9]|lpt[1-9])", stem):
                stem = f"subject-{stem}"
            subject_id = stem
            used = {subject["id"] for subject in subjects}
            # Do not claim an existing legacy subfolder when adding a new subject.
            while subject_id in used or (self.config.audio_dir / subject_id).exists():
                subject_id = f"{stem}-{uuid.uuid4().hex[:8]}"
            subject = {"id": subject_id, "name": name}
            root = self.config.audio_dir.resolve()
            folder = (root / subject_id).resolve()
            if not folder.is_relative_to(root):
                raise ValueError("The subject audio folder is outside the library.")
            folder.mkdir(parents=True, exist_ok=False)
            try:
                self._save([*subjects, subject])
            except BaseException:
                # This newly created empty directory is safe to remove if the
                # catalog update fails; never remove user-supplied recordings.
                try:
                    folder.rmdir()
                except OSError:
                    pass
                raise
            return self._display(subject)

    def rename(self, subject_id, name):
        name = self._name(name)
        with _CATALOG_LOCK:
            self.get(subject_id)
            subjects = self._load()
            if any(subject["id"] != subject_id and subject["name"].casefold() == name.casefold()
                   for subject in subjects):
                raise ValueError("A subject with that name already exists.")
            for subject in subjects:
                if subject["id"] == subject_id:
                    subject["name"] = name
                    result = subject
            self._save(subjects)
            return self._display(result)
