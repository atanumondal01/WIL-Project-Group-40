"""Terminal chat for audio lec. Run python -m lecture_chatbot for the browser."""
import argparse
from .rag import Config, answer_question

def main():
    parser = argparse.ArgumentParser(description="Chat with lecture recordings")
    parser.add_argument("question", nargs="?")
    parser.add_argument("--lecture", help="Filename, e.g. Lecture1.mp3")
    parser.add_argument("--subject", default="case-studies", help="Subject ID, default: case-studies")
    args = parser.parse_args()
    config, history = Config.load(), []
    while True:
        try:
            question = args.question or input("Ask about your lectures (exit to stop): ").strip()
            if question.lower() in {"exit", "quit"}:
                break
            result = answer_question(config, question, args.lecture, history, subject=args.subject)
            print(result["answer"])
            for source in result["sources"]:
                print(f"  [{source['label']}] {source['file']} | {source['start_label']} - {source['end_label']}")
            history.extend([{"role": "user", "content": question},
                            {"role": "assistant", "content": result["answer"]}])
        except (ValueError, RuntimeError) as exc:
            print(f"Error: {exc}")
        except (EOFError, KeyboardInterrupt):
            break
        if args.question:
            break

if __name__ == "__main__":
    main()
